export class PostAd{
    id : number;
    authorName : string;
    mobile : number;
    email : string;
    postName : string;
    postPrice : number;
    postDes : string;
    image : string;
}