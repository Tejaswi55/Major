import { Component, OnInit } from '@angular/core';
import { PostAd} from '../Post';
import { PostAdvertisementService } from '../post-advertisement.service';
import { Routes, Router} from '@angular/router';

@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
  styleUrls: ['./description.component.css']
})
export class DescriptionComponent implements OnInit {
  posts: PostAd[] = [];
  post: PostAd = new PostAd();
  flag:number=0;
  constructor(private postAdService: PostAdvertisementService, private router: Router) { }

  ngOnInit() {
    this.postAdService.getPost().subscribe((post: PostAd[]) => this.posts = post)
  }

}
