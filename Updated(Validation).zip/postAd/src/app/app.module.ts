import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, Router, RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { PostAdComponent } from './post-ad/post-ad.component';
import { PostAdvertisementService } from './post-advertisement.service';
import { ShowPostComponent } from './show-post/show-post.component';
import { CategoryComponent } from './category/category.component';
import { SortComponent } from './sort/sort.component';
import { DescriptionComponent } from './description/description.component';

const appRoutes: Routes=[
  {path:'', component:PostAdComponent},
  {path:'showpost', component:ShowPostComponent},
  {path: 'description', component:DescriptionComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    PostAdComponent,
    ShowPostComponent,
    CategoryComponent,
    SortComponent,
    DescriptionComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [PostAdvertisementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
