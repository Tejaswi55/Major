import { Component, OnInit } from '@angular/core';
import { PostAd} from '../Post';
import { PostAdvertisementService } from '../post-advertisement.service';
import { Routes, Router} from '@angular/router';

@Component({
  selector: 'app-show-post',
  templateUrl: './show-post.component.html',
  styleUrls: ['./show-post.component.css']
})
export class ShowPostComponent implements OnInit {
  posts: PostAd[] = [];
  post: PostAd = new PostAd();
  constructor(private postAdService: PostAdvertisementService, private router: Router) { 
    // var one= this.post.image;
  }

  

  ngOnInit() {
    this.postAdService.getPost().subscribe((post: PostAd[]) => this.posts = post)
  }

  seeDescription() : void
  {
    this.postAdService.getPost().subscribe((post: PostAd[]) => this.posts = post)

    this.router.navigate(['description'])
  }

}
