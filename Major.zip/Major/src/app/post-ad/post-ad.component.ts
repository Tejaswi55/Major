import { Component, OnInit } from '@angular/core';
import { PostAd } from '../Post';
import { PostAdvertisementService } from '../post-advertisement.service';
import { Routes, Router} from '@angular/router';

@Component({
  selector: 'app-post-ad',
  templateUrl: './post-ad.component.html',
  styleUrls: ['./post-ad.component.css']
})
export class PostAdComponent implements OnInit {

  posts: PostAd[] = [];
  post: PostAd = new PostAd();
  flag:number=0;
  Update:string;

  constructor(private postAdService: PostAdvertisementService, private router:Router) { }

  ngOnInit() {
    this.postAdService.getPost().subscribe((post: PostAd[]) => this.posts = post)
  }

  addPost(): void {
    this.postAdService.addPost(this.post);
    //console.log(JSON.stringify(this.posts));
    this.postAdService.getPost().subscribe((post: PostAd[]) => this.posts = post)
    console.log("Post added" + JSON.stringify(this.post));
    this.post = new PostAd();
    this.router.navigate(['showpost'])
  }

}