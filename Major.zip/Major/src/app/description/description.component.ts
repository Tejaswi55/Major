import { Component, OnInit } from '@angular/core';
import { PostAd} from '../Post';
import { PostAdvertisementService } from '../post-advertisement.service';

@Component({
  selector: 'app-description',
  templateUrl: './description.component.html',
  styleUrls: ['./description.component.css']
})
export class DescriptionComponent implements OnInit {
  posts: PostAd[] = [];
  post: PostAd = new PostAd();
  constructor(private postAdService: PostAdvertisementService) { }

  ngOnInit() {
    this.postAdService.getPost().subscribe((post: PostAd[]) => this.posts = post)
  }

}
