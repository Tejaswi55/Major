export class Courses {
    id:number
    courseName:string
    coursePrice:number
    courseDuration:number
}
